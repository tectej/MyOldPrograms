#####################problem statement##################

Problem Statement

Consider a two dimensional co-ordinate system with two axes; X & Y. This system is identified by positive integer co-ordinates. Meaning, every valid point in this system is represented by two values (x, y) where 0 < x,y <100.

You are given an input set of lines, specified by the co-ordinates of the two end-points.

Write a program to identify all closed shapes created by the specified lines.

Input Format (the program should accept this simple text file called "input.txt" placed in the classpath):

A1, B1; C1, D1

A2, B2; C2, D2

�

An, Bn; Cn, Dn

Expected Output (based on actual values of the input lines):

There are two triangles and 1 square based on the input.

Triangle 1 with vertices (a1,b1; a2, b2; a3,b3)

Triangle 2 with vertices (a5,b5; a6, b6; a7, b7)

Square 1 with vertices (a8, b8; a9, b9; a10, b10; a11, b11)

Note:

The input data may be such that some shapes overlap.
You don't have to find shapes formed by intersection of two shapes. For example, if a square and triangle overlap such that there is another small triangle formed at the intersection, you don't have to report that.
For the sake of scope, report only the following shapes, if any - triangle, any quadrilateral, pentagon.


##############################################################################################





Running Instruction:

1) Extract all files into some folder.
   let us say: F:\Shape_Finder\
   
2) Open command Prompt and go upto the parent directory

3) Program takes an input file named Input.txt. Add the complete file path , or the path upto 
	Files parent directory into the  classpath of user environment variables.

4) To execute program type 
   
     java com.bil.ShapeFinder

   This will output all closed shapes formed by the given set of lines.

	
4) Incase if you change any source file ( .java) you need to compile that file again.

    To compile any particular files type command 
    javac -source 1.7 -d . FileName.java

    To compile all files type command 
    javac -source 1.7 -d . *.java
	
	This will put all .class files in com.bil directory.

5)  To run program repeat step 4.



    Defination of a closed Shape: 
	 
	Any shape that is formed by set of unique lines , set of unique vertices with each vertex
    connected with exactly two lines of that shape and all vertices does not forms a straight line.
	
	If shape is made of: 
	3 lines 			: Triangle
	4 lines     
        (all equal length)              : Square
	4 lines				: Quadrilateral
	5 lines				: pentagon
	
		
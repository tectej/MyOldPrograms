package com.bil;

import java.util.List;

class Triangle extends Shape {

	Triangle(){
		super();
	}

	public Triangle(List<Line> lines ,List<Vertex> vertices ) {
		super(lines,vertices);
	}
}
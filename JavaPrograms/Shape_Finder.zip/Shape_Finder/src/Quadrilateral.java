package com.bil;

import java.util.List;

class Quadrilateral extends Shape{

	public Quadrilateral() {
		super();
	}

	public Quadrilateral(List<Line> lines ,List<Vertex> vertices ) {
		super(lines,vertices);
	}

}
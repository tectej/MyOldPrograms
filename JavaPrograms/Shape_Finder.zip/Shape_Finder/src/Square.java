package com.bil;

import java.util.List;

public class Square extends Quadrilateral {

	public Square() {
      
	}

	public Square(List<Line> lines, List<Vertex> vertices) {
		super(lines, vertices);
	}

}

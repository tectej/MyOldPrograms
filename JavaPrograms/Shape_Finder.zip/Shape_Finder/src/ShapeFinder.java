package com.bil;

import static com.bil.NumberToWord.numberToWords;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ShapeFinder {

	/**
	 * Date- 13-01-2015
	 * @author Tejas Patil
	 *  
	 *  Problem: Given a set of Lines , Find all closed shapes it can form. (Triangle,Quadrilateral,Pentagon)
	 */

	private Set<Pentagon> pentagonSet;
	private Set<Quadrilateral> quadrilateralSet;
	private Set<Triangle> triangleSet;

	public static void main(String[] args) {

		ShapeFinder shapeFinder = new ShapeFinder();

		List<Line> linesList = Resource.getInputs();

		shapeFinder.triangleSet = new HashSet<Triangle>();
		shapeFinder.quadrilateralSet = new HashSet<Quadrilateral>();
		shapeFinder.pentagonSet = new HashSet<Pentagon>();

		shapeFinder.findShapes(linesList);

		String outputString = shapeFinder.getOutputString(
				shapeFinder.triangleSet, shapeFinder.quadrilateralSet,
				shapeFinder.pentagonSet);

		System.out.print(outputString);
	}

	/**
	 * Method that generate final output String to be printed
	 * 
	 * @param triangleSet
	 * @param quadrilateralSet
	 * @param pentagonSet
	 * @return output string including all the details
	 */
	public String getOutputString(Set<Triangle> triangleSet,
			Set<Quadrilateral> quadrilateralSet, Set<Pentagon> pentagonSet) {

		Set<Square> squaresSet = getSquares(new HashSet<Shape>(quadrilateralSet));

		Iterator<Square> squareIterator = squaresSet.iterator();

		while(squareIterator.hasNext()){
			quadrilateralSet.remove(squareIterator.next());
		}

		int triangles = triangleSet.size();
		int quadrilaterals = quadrilateralSet.size();
		int pentagons = pentagonSet.size();
		int squares = squaresSet.size();

		StringBuffer outputString = new StringBuffer("\nThere");

		if (triangles == 0 && triangles == quadrilaterals
				&& triangles == pentagons && triangles == squares) {
			outputString
			.append(" are no closed shapes formed from given set of Lines.");
			return outputString.toString();
		}

		String triangleString = ((triangles != 0) ? (triangles == 1) ? 1 + " triangle"
				: numberToWords(Integer.toString(triangles)) + " triangles"
				: "");

		String squareString = ((squares != 0) ? (squares == 1) ? 1 + " square"
				: numberToWords(Integer.toString(squares)) + "  squares" : "");

		String quadrilateralString = ((quadrilaterals != 0) ? (quadrilaterals == 1) ? 1 + " quadrilateral"
				: numberToWords(Integer.toString(quadrilaterals))
				+ " quadrilaterals"
				: "");

		String pentagonString = ((pentagons != 0) ? (pentagons == 1) ? 1 + " pentagon"
				: numberToWords(Integer.toString(pentagons)) + " pentagons"
				: "");

		int firstNum = (triangles != 0) ? triangles : (squares != 0) ? squares
				: (quadrilaterals != 0) ? quadrilaterals : pentagons;

		outputString.append((firstNum > 1) ? " are "
				: ((firstNum == 1) ? " is " : ""));
		outputString.append(triangleString);

		if (triangles != 0 && squares > 0) {
			outputString.append(" and ");
		}

		outputString.append(squareString);

		if ((triangles != 0 | squares != 0) && quadrilaterals > 0) {
			outputString.append(" and ");
		}

		outputString.append(quadrilateralString);

		if ((triangles != 0 | squares != 0 | quadrilaterals != 0)
				&& pentagons > 0) {
			outputString.append(" and ");
		}

		outputString.append(pentagonString);

		outputString.append(" based on the input.");

		outputString.append(getDetailedOutput(triangleSet));
		outputString.append(getDetailedOutput(squaresSet));
		outputString.append(getDetailedOutput(quadrilateralSet));
		outputString.append(getDetailedOutput(pentagonSet));

		return outputString.toString();
	}

	/**
	 * Method that returns details of each shape's individual object
	 * 
	 * @param shapeSet
	 * @return detailed outputString for each shape. in format 
	 *          ShapeName number with vertices(vertices details) 
	 */
	private String getDetailedOutput(Set<? extends Shape> shapeSet) {

		Iterator<? extends Shape> shapeIterator = shapeSet.iterator();
		StringBuffer outputString = new StringBuffer();
		for (int i = 1; shapeIterator.hasNext(); i++) {
			Shape shape = shapeIterator.next();
			String shapeName = "";
			if (shape instanceof Triangle) {
				shapeName = "Triangle ";
			} else if (shape instanceof Square) {
				shapeName = "Square ";
			} else if (shape instanceof Quadrilateral) {
				shapeName = "Quadrilateral ";
			} else if (shape instanceof Pentagon) {
				shapeName = "Pentagon ";
			}
			outputString.append("\n"+shapeName + i + " with vertices(");

			int flag = 0;

			Collections.sort(shape.vertices);
			for (Vertex v : shape.vertices) {
				if (flag == 0) {
					flag = 1;
					outputString.append(v.getX() + "," + v.getY());
					continue;
				}
				outputString.append(";" + v.getX() + "," + v.getY());
			}
			outputString.append(")");
		}
		return outputString.toString();
	}

	/**
	 * Method that identifies which Quadrilaterals are Square.
	 * 
	 * @param shapeSet
	 * @return Set of Squares
	 *  
	 */
	public Set<Square> getSquares(Set<Shape> shapeSet) {

		Set<Square> squares = new HashSet<Square>();

		Iterator<Shape> shapeIterator = shapeSet.iterator();

		while (shapeIterator.hasNext()) {

			Shape shape = shapeIterator.next();
			Quadrilateral quadrilateral = null;

			if (shape instanceof Quadrilateral) {
				quadrilateral = (Quadrilateral) shape;
			} else {
				continue;
			}

			Line firstLine = quadrilateral.lines.get(0);

			boolean isSquare = true;
			for (Line otherLines : quadrilateral.lines) {
				if (firstLine.getLength() != otherLines.getLength()) {
					isSquare = false;
					break;
				}
			}

			if (isSquare) {
				Square square = new Square(quadrilateral.lines,quadrilateral.vertices);
				squares.add(square);
			}
		}


		return squares;
	}

	/**
	 * Method that iterates over all possible combinations of lines to find various shapes like triangle , Quadrilateral , Pentagon.
	 * 
	 * @param linesList
	 * 
	 */
	public void findShapes(List<Line> linesList) {
		int no_of_lines = linesList.size();
		for (int i = 0; i < no_of_lines; i++) {
			for (int j = i + 1; j < no_of_lines; j++) {
				for (int k = j + 1; k < no_of_lines; k++) {

					List<Line> threeLines = new ArrayList<Line>();
					Line l1 = linesList.get(i);
					Line l2 = linesList.get(j);
					Line l3 = linesList.get(k);

					threeLines.add(l1);threeLines.add(l2);threeLines.add(l3);

					Set<Vertex> triangleHS = checkForAnyShape(threeLines);

					if (triangleHS.size() == 3) {
						if (!checkForStraightLine(threeLines)) {
							Triangle tri = new Triangle(threeLines, new ArrayList<Vertex>(triangleHS));
							triangleSet.add(tri);
							tri = null;
						}
					}
					findQuadrilateral(k, threeLines, linesList, no_of_lines);
				}
			}
		}
	}

	/**
	 * method that checks if the given set of lines possibly can form a shape.
	 * @param lines
	 * @return set of vertices of newly recognized shape.
	 */
	public Set<Vertex> checkForAnyShape(List<Line> lines){
		Set<Vertex> tempHS = new HashSet<Vertex>();
		if (checkForUniqueLines(lines)) {
			for (Line l : lines) {
				tempHS.add(l.getVertex1());
				tempHS.add(l.getVertex2());
			}
		}
		return tempHS;
	}

	/**
	 * Method that finds and adds Quadrilaterals to quadrilateralSet
	 * 
	 * @param k
	 * @param threeLines
	 * @param linesList
	 * @param no_of_lines
	 */

	public void findQuadrilateral(int k,List<Line> threeLines ,List<Line> linesList,int no_of_lines){

		for(int l=k+1;l<no_of_lines;l++){

			List<Line> fourLines = new ArrayList<Line>(threeLines);
			Line l4 = linesList.get(l);
			fourLines.add(l4);

			Set<Vertex> quadrilateralHS = checkForAnyShape(fourLines);			

			if (quadrilateralHS.size() == 4) {
				if(checkForClosedShape(fourLines)){
					if (!checkForStraightLine(fourLines)) {
						Quadrilateral quad = new Quadrilateral(fourLines, new ArrayList<Vertex>(quadrilateralHS));
						quadrilateralSet.add(quad);
						quad = null;
					}
				}
			}
			findPentagon(l, fourLines, linesList, no_of_lines);
		}
	}
	
	/**
	 * Method that finds and adds Pentagons to pentagonSet
	 * 
	 * @param l  
	 * @param fourLines
	 * @param linesList
	 * @param no_of_lines
	 */

	public void findPentagon(int l,List<Line> fourLines ,List<Line> linesList,int no_of_lines){

		for(int m=l+1;m<no_of_lines;m++){

			List<Line> fiveLines = new ArrayList<Line>(fourLines);
			Line l5 = linesList.get(m);
			fiveLines.add(l5);

			Set<Vertex> pentagonHS = checkForAnyShape(fiveLines);			

			if (pentagonHS.size() == 5) {
				if(checkForClosedShape(fiveLines)){
					if (!checkForStraightLine(fiveLines)) {
						Pentagon pentagon = new Pentagon(fiveLines, new ArrayList<Vertex>(pentagonHS));
						pentagonSet.add(pentagon);
						pentagon = null;
						break;
					}
				}
			}

		}
	}

	/**
	 * Method that calculate degree of each vertex and returns true only if it is 2.
	 * 
	 * @param lines
	 * @return boolean value that tells if passed set of lines forms a closed shape.
	 */

	public boolean checkForClosedShape(List<Line> lines) {

		Map<Vertex, Integer> vertexDegree = new HashMap<Vertex, Integer>();
		Integer count = 0;

		boolean isClosedShape = true;

		for(Line l:lines){

			Vertex[] vertex = {l.getVertex1(),l.getVertex2()};

			for(Vertex v:vertex){
				if ((count = vertexDegree.put(v, 1)) != null) {
					vertexDegree.put(v, ++count);
					if (count > 2) {
						isClosedShape = false;
						break;
					}
				}
			}  
		}
		return isClosedShape;
	}

/**
 * Method that checks that passed lines are all unique.
 *  
 * @param lines
 * @return boolean value that tells if the lines passed are unique or not.
 */
	public boolean checkForUniqueLines(List<Line> lines) {
		int size = lines.size();
		for (int i = 0; i < size; i++) {
			for (int j = i + 1; j < size; j++) {
				if (lines.get(i).equals(lines.get(j))) {
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * Method that checks that the line segment passed forms a 2D shape and not a straight line
	 * eg. (10,10;20,20;30,30) forms a stright line. 
	 * 
	 * @param lines
	 * @return boolean value for straight line check
	 */

	public boolean checkForStraightLine(List<Line> lines) {
		Set<Double> slopeSet = new HashSet<Double>();

		for (Line l : lines) {
			Vertex vertex1 = l.getVertex1();
			Vertex vertex2 = l.getVertex2();

			double x1, y1, x2, y2;

			x1 = vertex1.getX();
			y1 = vertex1.getY();

			x2 = vertex2.getX();
			y2 = vertex2.getY();

			double slope = (y2 - y1) / (x2 - x1);

			slopeSet.add(slope);
		}

		if (slopeSet.size() == 1) {
			return true;
		}
		return false;
	}


}
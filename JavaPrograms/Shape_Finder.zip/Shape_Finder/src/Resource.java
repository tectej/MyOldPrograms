package com.bil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;

public class Resource
{
    public static BufferedReader getFileBuffedReader(){
    
    	BufferedReader br = null;
    	try{
    	Properties properties = System.getProperties();
    	String classpath = properties.getProperty("java.class.path");
    	String[] classpaths = classpath.split(";");

    	for(String path:classpaths){
    	  if(path.indexOf("input.txt")!=-1){
    		   br=new BufferedReader(new FileReader(path));
    		   break;
    	  }
    	}

    	if(br==null){
             InputStream is = ShapeFinder.class.getResourceAsStream("/input.txt");
          if(is!=null){
			 br=new BufferedReader(new InputStreamReader(is));
		   }
		else{
		   System.out.println("File Not Found in classpath."+"Make Sure either complete File path or path upto "
					+ "file's parent directory is included in user classpath variable"+"\neg. Complete File path: "
					+ "F:\\file\\input.txt \n"+"path upto File's parent Directory: F:\\file");
		   
			System.out.println("\nEnter complete File path here: \t");
			
			Scanner sc = new Scanner(System.in);

			String path = sc.next();

			File file = new File(path);  
			br=new BufferedReader(new FileReader(file));
			sc.close();
		}
    	}
    	}catch(FileNotFoundException fnf){
    		 fnf.printStackTrace();
    	}
    	return br;
    }
    
    public static List<Line> getInputs() {

		BufferedReader br = Resource.getFileBuffedReader();

		String next;
		Set<Line> lines = new HashSet<Line>();

		try {
			while ((next = br.readLine()) != null) {

				if ("".equals(next.trim())) {
					continue;
				}

				String[] points = next.split(";");

				if (points.length != 2) {
					continue;
				}

				Line l = new Line();

				for (int i = 0; i < 2; i++) {
					if (points[i] == null) {
						break;
					}

					String[] pointsxy = points[i].split(",");

					Vertex p = new Vertex();

					String point1 = "", point2 = "";

					if (pointsxy.length == 2) {
						point1 = pointsxy[0];
						point2 = pointsxy[1];
					}

					if ("".equals(point1) || "".equals(point2)
							|| " ".equals(point1.trim())
							|| " ".equals(point2.trim())) {
						break;
					}

					p.setX(Integer.parseInt(point1.trim()));
					p.setY(Integer.parseInt(point2.trim()));

					if (i == 0) {
						l.setVertex1(p);
					}

					l.setVertex2(p);
					p = null;
				}

			if(l.getLength()!=0)
				lines.add(l);
			}
			br.close();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		List<Line> linesList = new ArrayList<Line>(lines);

		for(Line l:linesList){
			 if(l.getLength()==0){
				 linesList.remove(l);
				 System.out.println(l);
			 }
		}
		return linesList;
	}
}
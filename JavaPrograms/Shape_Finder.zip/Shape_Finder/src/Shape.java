package com.bil;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public abstract class Shape {
	
	/**
	 * Supeclass of all shapes like Triangle , Quadrilateral , Pentagon
	 * 
	 */

	protected List<Line> lines;
	protected List<Vertex> vertices;

	Shape(){
	   super();	
	}
	
	public Shape(List<Line> lines, List<Vertex> vertices) {
		super();
		this.lines = lines;
		this.vertices = vertices;
	}

	public List<Line> getLines() {
		return lines;
	}
	public void setLines(List<Line> lines) {
		this.lines = lines;
	}
	public List<Vertex> getVertices() {
		return vertices;
	}
	public void setVertices(List<Vertex> vertices) {
		this.vertices = vertices;
	}

	/**  Two shapes are equal if their sides have are equal co-ordinates.
	 *   Overrides equals(Object obj) method in class Object. 
	 */
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Shape){
			Shape shape = (Shape) obj;		
			Set<Line> lineSet = new HashSet<Line>();

			for(Line l:shape.lines){
				lineSet.add(l);
			}

			for(Line l:this.lines){
				lineSet.add(l);
			}

			if(lineSet.size()==3&&shape instanceof Triangle){
				return true;
			}else if(lineSet.size()==4&&shape instanceof Quadrilateral){
				return true;
			}else if(lineSet.size()==5&&shape instanceof Pentagon){
				return true;
			}
		}
		return false;
	}

	/**
	 * hashCode is perimeter of that shape.
	 */
	@Override
	public int hashCode() {

		int perimeter = 0;
		for(Line l : lines){
			perimeter+=l.getLength();	
		}
		return perimeter;
	}

	@Override
	public String toString() {

		String toString="";

		toString += (this instanceof Triangle)?"Triangle":(this instanceof Quadrilateral)? "Quadrilateral":(this instanceof Pentagon)?"Pentagon":"";

		for(Vertex vertex:vertices){
			toString+=vertex+" ";
		}
		
		return toString;
	}
}

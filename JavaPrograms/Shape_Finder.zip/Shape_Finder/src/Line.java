package com.bil;

public class Line {

	private Vertex vertex1;
	private Vertex vertex2;

	public Line(){

	}

	public Line(Vertex x, Vertex y) {
		vertex1 = x;
		vertex2 = y;
	}

	@Override
	public boolean equals(Object obj) {

		if(obj instanceof Line){
			Line line = (Line)obj;
			if(this.equalTo(line)){
				return true;
			}
		}
		return false;
	}

	public boolean equalTo(Line line){
		if((line.vertex1.equals(vertex1) && line.vertex2.equals(vertex2))||(line.vertex1.equals(vertex2) && line.vertex2.equals(vertex1))){
			return true;
		}
		return false;
	}

	public int getLength(){
		int x1,y1,x2,y2;
		x1=vertex1.getX();
		y1=vertex1.getY();
		x2=vertex2.getX();
		y2=vertex2.getY();

		if(x1==x2){
			return Math.abs(y2-y1);
		}
		else if (y1==y2){
			return Math.abs(x2-x1);
		}
		return (int)Math.sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)));
	} 

	public Vertex getVertex1() {
		return vertex1;
	}

	public Vertex getVertex2() {
		return vertex2;
	}

	@Override
	public int hashCode(){
		return getLength();
	}

	public void setVertex1(Vertex vertex1) {
		this.vertex1 = vertex1;
	}

	public void setVertex2(Vertex vertex2) {
		this.vertex2 = vertex2;
	}    

	@Override
	public String toString() {
		return "Line [ " + vertex1 +"------- " +vertex2+" ]";
	} 

}
package com.bil;

public class NumberToWord {
	/**
	 * Program that takes a numberic number and returns it in word format.
	 * eg. 2 -> two.
	 * 
	 * @param num
	 * @return number in word format.
	 */

	public static String numberToWords(String num) {
		String numToWord = "";
		
		int numLength = num.length() - 3;

		if (numLength > 0) {
			String seqString = "3";

			while (numLength - 2 > 0) {
				int rem = numLength - 2;
				seqString = seqString + "2";
				numLength = rem;
			}

			seqString = seqString + Integer.toString(numLength);

			seqString = new StringBuffer(seqString).reverse().toString();

			int index = num.length();

			int j = 0;
			for (int i = 0; i < seqString.length(); i++) {
				int nextblock = Integer.parseInt(Character.toString(seqString
						.charAt(i)));

				if (nextblock == 2) {
					String digit1 = Character.toString(num.charAt(j++));
					String digit2= Character.toString(num.charAt(j++));
					numToWord += getTwoDigitNumber(digit1+digit2);

				    if(!(digit1+digit2).equals("00")){
						numToWord += getPlaceValue(index);
				    } 
				    index = index - 2;
				}
				if (nextblock == 1) {

					
					int digit = Integer.parseInt(Character.toString(num.charAt(j++)));
					numToWord += numToWord(digit);

					
					if(!(digit==0)){
						numToWord += getPlaceValue(index);
					}

					index--;
				}
				if (nextblock == 3) {

					String digit1 = Character.toString(num.charAt(j++));
					String digit2 = Character.toString(num.charAt(j++));
					String digit3 = Character.toString(num.charAt(j++));
					
					numToWord += getThreeDigitNumber(digit1+digit2+digit3);

					index = index - 3;
				}
			}

		} else if (num.length() == 3) {
			numToWord += getThreeDigitNumber(num);
		} else if (num.length() == 2) {
			numToWord += getTwoDigitNumber(num);
		} else if (num.length() == 1) {
			numToWord += getOneDigitNumber(num);
		}
		return numToWord;
	}

	private static String getPlaceValue(int index) {
		String placeValue = "";
		if (index == 5 | index == 4) {
			placeValue += " thousand ";
		} else if (index == 6 | index == 7) {
			placeValue += " lakh ";
		} else if (index == 8 | index == 9) {
			placeValue += " crores ";
		}
		return placeValue;
	}

	private static String getTwoDigitNumber(String num) {

		String twoDigitToWord = "";

		int number = Integer.parseInt(num);

		if (number < 20) {
			return numToWord(number);
		}

		Integer tensPlace = Integer.parseInt(Character.toString(num.charAt(0)));
		tensPlace = tensPlace * 10;
		Integer unitsPlace = Integer
				.parseInt(Character.toString(num.charAt(1)));
		twoDigitToWord = twoDigitToWord + numToWord(tensPlace) + " "
				+ getOneDigitNumber(unitsPlace.toString());
		return twoDigitToWord;
	}

	private static String getThreeDigitNumber(String num) {

		String threeDigitToWord = "";
		
		String digit1 = Character.toString(num.charAt(0));
		String digit2 = Character.toString(num.charAt(1));
		String digit3 = Character.toString(num.charAt(2));
		
		Integer hundredsPlace = Integer.parseInt(digit1);

		if(Integer.parseInt(num)>100){
		threeDigitToWord = numToWord(hundredsPlace)
				+ ((hundredsPlace > 0) ? " hundred " : "")
				+ (((Integer.parseInt(num) % 100)>0)? "and ":"")
				+ getTwoDigitNumber(digit2+digit3);
		}else if(Integer.parseInt(num)<100){
			threeDigitToWord=getTwoDigitNumber(digit2+digit3);
		}else if (Integer.parseInt(num)==100) {
			threeDigitToWord="hundred";
		}
		
		return threeDigitToWord;
	}

	private static String getOneDigitNumber(String num) {
		return numToWord(Integer.parseInt(num.trim()));
	}

	private static String numToWord(int num) {

		String inWord = "";
		switch (num) {

		case 1:
			inWord = "one";
			break;
		case 2:
			inWord = "two";
			break;
		case 3:
			inWord = "three";
			break;
		case 4:
			inWord = "four";
			break;
		case 5:
			inWord = "five";
			break;
		case 6:
			inWord = "six";
			break;
		case 7:
			inWord = "seven";
			break;
		case 8:
			inWord = "eight";
			break;
		case 9:
			inWord = "nine";
			break;

		case 10:
			inWord = "ten";
			break;

		case 11:
			inWord = "eleven";
			break;

		case 12:
			inWord = "twelve";
			break;

		case 13:
			inWord = "thirteen";
			break;

		case 14:
			inWord = "fourteen";
			break;

		case 15:
			inWord = "fifteen";
			break;

		case 16:
			inWord = "sixteen";
			break;

		case 17:
			inWord = "seventeen";
			break;

		case 18:
			inWord = "eighteen";
			break;

		case 19:
			inWord = "nineteen";
			break;

		case 20:
			inWord = "twenty";
			break;

		case 30:
			inWord = "thirty";
			break;

		case 40:
			inWord = "forty";
			break;

		case 50:
			inWord = "fifty";
			break;

		case 60:
			inWord = "sixty";
			break;

		case 70:
			inWord = "seventy";
			break;

		case 80:
			inWord = "eighty";
			break;

		case 90:
			inWord = "ninety";
			break;

		}
		return inWord;
	}
}
package com.bil;

import java.util.List;

class Pentagon extends Shape{
	
	public Pentagon() {
		super();
	}
	public Pentagon(List<Line> lines, List<Vertex> vertices) {
		super(lines, vertices);
	}
  
}